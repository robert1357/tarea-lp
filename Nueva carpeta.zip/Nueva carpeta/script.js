// Variables globales
let transactions = [];
let totalIncome = 0;
let totalExpenses = 0;
let totalSavings = 0;

// Función para actualizar el balance en la interfaz
function updateBalance() {
    document.getElementById('total-income').textContent = totalIncome.toFixed(2);
    document.getElementById('total-expenses').textContent = totalExpenses.toFixed(2);
    document.getElementById('total-savings').textContent = totalSavings.toFixed(2);
}

// Función para agregar una transacción al historial
function addTransactionToList(transaction) {
    const transactionList = document.getElementById('transactions');
    const li = document.createElement('li');
    li.innerHTML = `${transaction.type === 'income' ? 'Ingreso' : 'Gasto'} - ${transaction.category}: $${transaction.amount.toFixed(2)}`;
    transactionList.appendChild(li);
}

// Función para procesar el formulario de transacción
document.getElementById('transaction-form').addEventListener('submit', function (event) {
    event.preventDefault();

    // Obtener los valores del formulario
    const type = document.getElementById('type').value;
    const category = document.getElementById('category').value;
    const amount = parseFloat(document.getElementById('amount').value);

    // Crear un objeto de transacción
    const transaction = {
        type,
        category,
        amount
    };

    // Actualizar las variables globales
    if (type === 'income') {
        totalIncome += amount;
        totalSavings += amount;
    } else if (type === 'expense') {
        totalExpenses += amount;
        totalSavings -= amount;
    }

    // Guardar la transacción en la lista global
    transactions.push(transaction);

    // Actualizar la interfaz
    addTransactionToList(transaction);
    updateBalance();

    // Limpiar el formulario
    document.getElementById('transaction-form').reset();
});

// Inicializar el balance al cargar la página
updateBalance();
